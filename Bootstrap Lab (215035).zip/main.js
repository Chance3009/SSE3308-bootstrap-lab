$(document).ready(function(){
    $('.header').height($(window).height());
    })
    
    console.log("HELLO");